import SwiftUI
import MapKit

struct TripsView: View {
    @EnvironmentObject var model: DriveModel
    @ObservedObject var store: TripStore
    @Environment(\.dismiss) private var dismiss
    @State private var confirmAll = false

    var body: some View {
        let t = model.t
        let items = Array(store.trips.reversed())
        NavigationStack {
            Group {
                if items.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "car.side").font(.system(size: 44)).foregroundStyle(Color.muted)
                        Text(t.noTrips).multilineTextAlignment(.center).foregroundStyle(Color.muted)
                    }
                    .padding(32)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        ForEach(items) { trip in
                            NavigationLink { TripDetailView(trip: trip) } label: { TripRow(trip: trip, live: store.current?.id == trip.id) }
                        }
                        .onDelete { idx in idx.map { items[$0].id }.forEach(store.delete) }
                    }
                }
            }
            .navigationTitle(t.tripsTitle)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button(t.close) { dismiss() } }
                if !items.isEmpty {
                    ToolbarItem(placement: .destructiveAction) {
                        Button(t.deleteAll, role: .destructive) { confirmAll = true }.tint(Color.danger)
                    }
                }
            }
            .confirmationDialog(t.deleteAllConfirm, isPresented: $confirmAll, titleVisibility: .visible) {
                Button(t.deleteAll, role: .destructive) { store.deleteAll() }
                Button(t.close, role: .cancel) {}
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct TripRow: View {
    @EnvironmentObject var model: DriveModel
    let trip: Trip
    let live: Bool

    var body: some View {
        let t = model.t
        VStack(alignment: .leading, spacing: 6) {
            Text("\(t.date(trip.start)) · \(t.time(trip.start)) – \(live ? t.inProgress : t.time(trip.end))")
                .font(.headline)
            HStack(spacing: 14) {
                Label(t.km(trip.distance), systemImage: "road.lanes")
                Label(t.dur(trip.end.timeIntervalSince(trip.start)), systemImage: "clock")
                Label("\(trip.maxKmh)", systemImage: "speedometer")
                if trip.alerts > 0 { Label("\(trip.alerts)", systemImage: "exclamationmark.triangle").foregroundStyle(Color.warn) }
            }
            .font(.footnote.monospacedDigit())
            .foregroundStyle(Color.muted)
            if !trip.roads.isEmpty {
                Text(trip.roads.prefix(4).map(\.name).joined(separator: " ← "))
                    .font(.footnote).foregroundStyle(Color.muted).lineLimit(1)
            }
        }
        .padding(.vertical, 4)
    }
}

struct TripDetailView: View {
    @EnvironmentObject var model: DriveModel
    let trip: Trip
    @State private var gpxURL: URL?

    var body: some View {
        let t = model.t
        let coords = trip.coords
        List {
            Section {
                Map(initialPosition: .automatic) {
                    MapPolyline(coordinates: coords).stroke(Color.ok, lineWidth: 5)
                    if let a = coords.first {
                        Annotation(t.started, coordinate: a) { dot(Color.ok) }
                    }
                    if let b = coords.last {
                        Annotation(t.ended, coordinate: b) { dot(Color.danger) }
                    }
                }
                .frame(height: 280)
                .listRowInsets(EdgeInsets())
            }

            Section {
                if let gpxURL {
                    ShareLink(item: gpxURL, subject: Text("\(t.tripOf) \(t.date(trip.start))"), message: Text(trip.summary(t))) {
                        Label(t.share, systemImage: "square.and.arrow.up").font(.headline)
                    }
                } else {
                    ShareLink(item: trip.summary(t)) {
                        Label(t.share, systemImage: "square.and.arrow.up").font(.headline)
                    }
                }
            }

            Section {
                row(t.started, t.time(trip.start), link: trip.points.first)
                row(t.ended, t.time(trip.end), link: trip.points.last)
                LabeledContent(t.duration, value: t.dur(trip.end.timeIntervalSince(trip.start)))
                LabeledContent(t.distance, value: t.km(trip.distance))
                LabeledContent(t.maxSpeed, value: "\(trip.maxKmh)")
                LabeledContent(t.alerts, value: "\(trip.alerts)")
            }

            Section(t.roadsLabel) {
                if trip.roads.isEmpty {
                    Text(t.noRoads).foregroundStyle(Color.muted)
                } else {
                    ForEach(trip.roads, id: \.self) { r in
                        HStack {
                            Text(t.time(r.t)).foregroundStyle(Color.muted).monospacedDigit()
                            Text(r.name)
                            Spacer()
                            if let l = r.limit { Text("\(l)").bold().monospacedDigit() }
                        }
                    }
                }
            }
        }
        .navigationTitle(t.date(trip.start))
        .navigationBarTitleDisplayMode(.inline)
        .task { gpxURL = trip.gpxFile() }
    }

    private func dot(_ c: Color) -> some View {
        Circle().fill(c).frame(width: 14, height: 14).overlay(Circle().stroke(.white, lineWidth: 2))
    }

    @ViewBuilder
    private func row(_ label: String, _ time: String, link p: TripPoint?) -> some View {
        LabeledContent(label) {
            VStack(alignment: .trailing, spacing: 2) {
                Text(time)
                if let p, let url = URL(string: Trip.mapsLink(p)) {
                    Link(String(format: "%.5f, %.5f", p.lat, p.lon), destination: url)
                        .font(.caption.monospacedDigit())
                        .environment(\.layoutDirection, .leftToRight)
                }
            }
        }
    }
}
