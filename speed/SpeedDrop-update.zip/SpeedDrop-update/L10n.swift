import Foundation

enum AppLang: String, CaseIterable, Identifiable {
    case ar, en
    var id: String { rawValue }
    var isRTL: Bool { self == .ar }
    var speechCode: String { self == .ar ? "ar-SA" : "en-US" }
}

enum VoiceMode: String, CaseIterable, Identifiable {
    case voice, beep, off
    var id: String { rawValue }
}

/// All user-facing text, Arabic (Gulf/Egyptian-friendly) and English.
struct L10n {
    let lang: AppLang
    private var ar: Bool { lang == .ar }

    var appName: String { ar ? "نبّهني" : "SpeedDrop" }
    var gps: String { "GPS" }
    var roadData: String { ar ? "بيانات الطريق" : "Road data" }
    var settings: String { ar ? "الإعدادات" : "Settings" }
    var yourSpeed: String { ar ? "سرعتك كم/س" : "Your speed km/h" }
    var allowedTo: String { ar ? "مسموح لحد" : "Allowed up to" }
    var manualLabel: String { ar ? "لو الحد غلط أو مش ظاهر، اختاره بإيدك" : "Limit wrong or missing? Pick it yourself" }
    var auto: String { ar ? "تلقائي" : "Auto" }

    var headline: String { ar ? "نبّهني لما السرعة تنزل" : "Alert me when the limit drops" }
    var intro: String {
        ar ? "بيقرا سرعتك من GPS وحد السرعة من خريطة الطريق. لو الحد نزل وإنت لسه فوق المسموح، بيقولّك بصوت ويصفّر. بيفضل شغّال حتى لو قفلت الموبايل أو فتحت أبلكيشن تاني، وWaze شغّال على CarPlay زي ما هو."
           : "Reads your speed from GPS and the speed limit from the road map. If the limit drops while you are still above the allowed speed, it tells you out loud and beeps. It keeps working with the phone locked or another app open, while Waze runs on CarPlay as usual."
    }
    var start: String { ar ? "ابدأ" : "Start" }
    var stop: String { ar ? "إيقاف" : "Stop" }
    var demo: String { ar ? "جرّب التنبيه (محاكاة)" : "Try the alert (simulation)" }

    var toleranceLabel: String { ar ? "هامش السماح فوق الحد" : "Margin above the limit" }
    var toleranceNote: String {
        ar ? "التنبيه بيشتغل لما سرعتك تعدّي (الحد + الهامش). الهامش مش ثابت في كل الطرق والإمارات، فالأسلم تقلّله."
           : "The alert fires when your speed passes (limit + margin). The margin is not the same on every road and emirate, so a smaller one is safer."
    }
    var none: String { ar ? "بدون" : "None" }
    var languageLabel: String { ar ? "اللغة" : "Language" }
    var soundLabel: String { ar ? "الصوت" : "Sound" }
    func voiceMode(_ m: VoiceMode) -> String {
        switch m {
        case .voice: return ar ? "صوت + صفارة" : "Voice + beep"
        case .beep: return ar ? "صفارة بس" : "Beep only"
        case .off: return ar ? "صامت" : "Silent"
        }
    }
    var anyChangeLabel: String { ar ? "تنبيه عند أي تغيير في الحد (حتى لو زاد)" : "Alert on any limit change (even when it goes up)" }
    var keepScreenOn: String { ar ? "خلي الشاشة منوّرة" : "Keep screen on" }
    var testAlert: String { ar ? "اسمع التنبيه" : "Hear the alert" }
    var done: String { ar ? "تمام" : "Done" }

    var waitingGPS: String { ar ? "مستني إشارة GPS…" : "Waiting for GPS…" }
    var noLimit: String { ar ? "مش لاقي حد السرعة هنا، اختاره بإيدك" : "No speed limit found here. Pick it yourself" }
    func over(_ limit: Int, _ speed: Int) -> String { ar ? "خفّف! الحد \(limit) وإنت \(speed)" : "Slow down! Limit \(limit), you are at \(speed)" }
    func inMargin(_ max: Int) -> String { ar ? "فوق الحد، جوّه الهامش (لحد \(max))" : "Above the limit, within margin (up to \(max))" }
    var withinLimit: String { ar ? "تمام، ضمن الحد" : "Good, within the limit" }
    var locationDenied: String {
        ar ? "الموقع مقفول. فعّله من الإعدادات ← الخصوصية ← خدمات الموقع ← نبّهني"
           : "Location is off. Turn it on in Settings > Privacy > Location Services > SpeedDrop"
    }

    var map: String { ar ? "خريطة" : "Map" }
    var gauge: String { ar ? "العدّاد" : "Gauge" }

    // Trips
    var trips: String { ar ? "الرحلات" : "Trips" }
    var tripsLong: String { ar ? "سجل الرحلات" : "Trip history" }
    var tripsTitle: String { ar ? "سجل الرحلات" : "Trip history" }
    var noTrips: String { ar ? "لسه مفيش رحلات. أول ما تدوس ابدأ وتتحرك، الرحلة هتتسجّل هنا.\nالسجل محفوظ على الموبايل ده بس." : "No trips yet. Press Start and drive; the trip is saved here.\nHistory is stored on this phone only." }
    var tripOf: String { ar ? "رحلة" : "Trip" }
    var started: String { ar ? "البداية" : "Start" }
    var ended: String { ar ? "النهاية" : "End" }
    var duration: String { ar ? "المدة" : "Duration" }
    var distance: String { ar ? "المسافة" : "Distance" }
    var maxSpeed: String { ar ? "أعلى سرعة" : "Top speed" }
    var alerts: String { ar ? "تنبيهات السرعة" : "Speed alerts" }
    var roadsLabel: String { ar ? "الطرق" : "Roads" }
    var noRoads: String { ar ? "مفيش أسماء طرق متسجّلة" : "No road names recorded" }
    var close: String { ar ? "قفل" : "Close" }
    var deleteAll: String { ar ? "امسح الكل" : "Delete all" }
    var deleteAllConfirm: String { ar ? "تمسح كل الرحلات؟" : "Delete all trips?" }
    var inProgress: String { ar ? "جارية الآن" : "In progress" }
    var share: String { ar ? "شارك الرحلة" : "Share trip" }

    private var locale: Locale { Locale(identifier: ar ? "ar-AE" : "en-GB") }
    func date(_ d: Date) -> String { d.formatted(Date.FormatStyle(date: .abbreviated, time: .omitted).weekday(.abbreviated).locale(locale)) }
    func time(_ d: Date) -> String { d.formatted(Date.FormatStyle(date: .omitted, time: .shortened).locale(locale)) }
    func dur(_ s: TimeInterval) -> String {
        let m = Int((s / 60).rounded())
        if m < 60 { return ar ? "\(m) د" : "\(m) min" }
        return ar ? "\(m / 60) س \(m % 60) د" : "\(m / 60) h \(m % 60) min"
    }
    func km(_ metres: Double) -> String {
        let k = metres / 1000
        let v = k < 10 ? String(format: "%.1f", k) : String(format: "%.0f", k)
        return ar ? "\(v) كم" : "\(v) km"
    }

    // Spoken
    func sayLimit(_ l: Int) -> String { ar ? "حد السرعة \(l)" : "Speed limit \(l)" }
    func sayDropOver(_ l: Int, _ max: Int) -> String { ar ? "انتبه، السرعة نزلت \(l). خفّف لـ \(max)" : "Warning, speed limit dropped to \(l). Slow down to \(max)" }
    func sayDrop(_ l: Int) -> String { ar ? "السرعة نزلت \(l)" : "Speed limit dropped to \(l)" }
    func sayOver(_ s: Int, _ max: Int) -> String { ar ? "انتبه، إنت ماشي \(s). المسموح \(max)" : "Warning, you are at \(s). Allowed \(max)" }
    func sayUp(_ l: Int) -> String { ar ? "السرعة \(l)" : "Speed limit \(l)" }
}
