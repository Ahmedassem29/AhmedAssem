import Foundation
import CoreLocation
import UIKit

enum Signal { case idle, ok, waiting, bad }
enum Status { case waiting, noLimit, ok, inMargin, over }

@MainActor
final class DriveModel: ObservableObject {
    // Settings (persisted)
    @Published var lang: AppLang { didSet { save(lang.rawValue, "lang") } }
    @Published var tolerance: Int { didSet { save(tolerance, "tol") } }
    @Published var voiceMode: VoiceMode { didSet { save(voiceMode.rawValue, "voice") } }
    @Published var alertOnAnyChange: Bool { didSet { save(alertOnAnyChange, "any") } }
    @Published var keepScreenOn: Bool { didSet { save(keepScreenOn, "screen"); applyIdleTimer() } }

    // Live state
    @Published private(set) var running = false
    @Published private(set) var speed: Int = 0
    @Published private(set) var autoLimit: Int?
    @Published var manualLimit: Int? { didSet { if manualLimit != oldValue { limitChanged(from: oldValue ?? autoLimit, to: effectiveLimit) } } }
    @Published private(set) var gps: Signal = .idle
    @Published private(set) var road: Signal = .idle
    @Published private(set) var locationDenied = false
    @Published private(set) var flashCount = 0
    @Published private(set) var limitPulse = 0
    @Published private(set) var hasFix = false

    var t: L10n { L10n(lang: lang) }
    var effectiveLimit: Int? { manualLimit ?? autoLimit }
    var allowed: Int? { effectiveLimit.map { $0 + tolerance } }
    var limitIsStale: Bool { manualLimit == nil && (autoLimit == nil || Date().timeIntervalSince(limitTime) > 20) }

    var status: Status {
        guard hasFix || demoRunning else { return .waiting }
        guard let lim = effectiveLimit else { return .noLimit }
        if speed > lim + tolerance { return .over }
        if speed > lim { return .inMargin }
        return .ok
    }

    private let location = LocationService()
    private let limits = SpeedLimitService()
    private let tomtom = TomTomService()
    private let alerts = AlertPlayer()
    let tripStore = TripStore()
    private var prev: CLLocation?
    private var limitTime = Date.distantPast
    private var candidate: Int?
    private var candidateCount = 0
    private var lastOverBeep = Date.distantPast
    private var lastOverSay = Date.distantPast
    private var wasOver = false
    private var demoRunning = false
    private var demoTask: Task<Void, Never>?

    init() {
        let d = UserDefaults.standard
        lang = AppLang(rawValue: d.string(forKey: "lang") ?? "") ?? .ar
        tolerance = d.object(forKey: "tol") as? Int ?? 20
        voiceMode = VoiceMode(rawValue: d.string(forKey: "voice") ?? "") ?? .voice
        alertOnAnyChange = d.object(forKey: "any") as? Bool ?? true
        keepScreenOn = d.object(forKey: "screen") as? Bool ?? true

        location.onLocation = { [weak self] loc in Task { @MainActor in self?.handle(loc) } }
        location.onAuthorization = { [weak self] s in
            Task { @MainActor in
                self?.locationDenied = (s == .denied || s == .restricted)
                if self?.locationDenied == true { self?.gps = .bad }
            }
        }
    }

    private func save(_ v: Any, _ k: String) { UserDefaults.standard.set(v, forKey: k) }

    // MARK: - control

    func start() {
        stopDemo()
        running = true
        gps = .waiting
        location.start()
        applyIdleTimer()
    }

    func stop() {
        running = false
        location.stop()
        tripStore.finish()
        stopDemo()
        hasFix = false; speed = 0; autoLimit = nil; prev = nil
        gps = .idle; road = .idle
        applyIdleTimer()
    }

    private func applyIdleTimer() {
        UIApplication.shared.isIdleTimerDisabled = running && keepScreenOn
    }

    // MARK: - GPS

    private func handle(_ loc: CLLocation) {
        guard running, !demoRunning else { return }
        guard loc.horizontalAccuracy >= 0, loc.horizontalAccuracy < 100 else { return }

        var kmh: Double? = loc.speed >= 0 ? loc.speed * 3.6 : nil
        var heading: Double? = loc.course >= 0 ? loc.course : nil
        if let p = prev {
            let d = loc.distance(from: p), dt = loc.timestamp.timeIntervalSince(p.timestamp)
            if kmh == nil, dt > 0 { kmh = d / dt * 3.6 }
            if heading == nil, d > 8 {
                let a = SpeedLimitService.xy(p.coordinate, origin: loc.coordinate)
                heading = SpeedLimitService.bearing(a, (0, 0))
            }
        }
        prev = loc
        let s = kmh ?? 0
        speed = Int(s.rounded())
        if s < 8 { heading = nil }
        hasFix = true
        tripStore.record(loc, kmh: s)
        gps = loc.horizontalAccuracy < 30 ? .ok : .waiting

        let coord = loc.coordinate
        let lang = self.lang
        let h = heading   // immutable copy for the async tasks below
        Task {
            if await limits.needsFetch(coord) {
                let has = await limits.hasData
                if !has { road = .waiting }
                let ok = await limits.fetch(around: coord, lang: lang.rawValue)
                road = ok ? .ok : .bad
            }
        }
        Task { await tomtom.lookup(coord, heading: h, lang: lang) }
        Task {
            let tt = await tomtom.freshLimit
            let osm = await limits.match(coord, heading: h)
            if tt != nil { road = .ok }
            applyMatch(tt ?? osm)
            var name = ""
            if tt != nil { name = await tomtom.roadName }
            if name.isEmpty, let osmName = await limits.nearestName(coord) { name = osmName }
            if !name.isEmpty { tripStore.road(name, limit: effectiveLimit) }
            checkOver()
        }
    }

    private func applyMatch(_ m: Int?) {
        guard let m else { return }
        if m == autoLimit {
            limitTime = Date(); candidate = nil; candidateCount = 0
            return
        }
        // Need two agreeing fixes before switching (ignores ramps and side roads).
        if m == candidate { candidateCount += 1 } else { candidate = m; candidateCount = 1 }
        if candidateCount >= 2 || autoLimit == nil {
            let old = effectiveLimit
            autoLimit = m; limitTime = Date(); candidate = nil; candidateCount = 0
            if manualLimit == nil { limitChanged(from: old, to: m) }
        }
    }

    // MARK: - alerts

    private func limitChanged(from old: Int?, to new: Int?) {
        guard let new, old != new else { return }
        limitPulse += 1
        guard let old else {
            if alertOnAnyChange { speak(t.sayLimit(new)) }
            return
        }
        let maxAllowed = new + tolerance
        if new < old {
            let over = speed > maxAllowed
            flashCount += 1
            beep(frequency: over ? 1150 : 900, duration: 0.18, count: over ? 4 : 2)
            let line = over ? t.sayDropOver(new, maxAllowed) : t.sayDrop(new)
            later(over ? 1.3 : 0.7) { $0.speak(line) }
            lastOverBeep = Date(); lastOverSay = Date(); wasOver = over
        } else if alertOnAnyChange {
            beep(frequency: 660, duration: 0.12, count: 1)
            let line = t.sayUp(new)
            later(0.25) { $0.speak(line) }
        }
    }

    /// Alert whenever speed passes limit + margin: strong alert on crossing,
    /// a beep every 4 s while over, and the spoken line again every 15 s.
    private func checkOver() {
        guard let lim = effectiveLimit else { return }
        let maxAllowed = lim + tolerance, now = Date()
        let over = speed > maxAllowed
        if over && !wasOver {
            if !demoRunning { tripStore.countAlert() }
            lastOverBeep = now; lastOverSay = now
            beep(frequency: 1150, duration: 0.18, count: 3, gap: 0.08)
            let line = t.sayOver(speed, maxAllowed)
            later(0.9) { $0.speak(line) }
        } else if over {
            if now.timeIntervalSince(lastOverSay) > 15 {
                lastOverSay = now; lastOverBeep = now
                beep(frequency: 1150, duration: 0.14, count: 2, gap: 0.08)
                let line = t.sayOver(speed, maxAllowed)
                later(0.7) { $0.speak(line) }
            } else if now.timeIntervalSince(lastOverBeep) > 4 {
                lastOverBeep = now
                beep(frequency: 1150, duration: 0.14, count: 2, gap: 0.08)
            }
        }
        wasOver = over
    }

    private func later(_ seconds: Double, _ action: @escaping @MainActor (DriveModel) -> Void) {
        Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            if let self { action(self) }
        }
    }

    private func beep(frequency: Double, duration: Double, count: Int, gap: Double = 0.1) {
        guard voiceMode != .off else { return }
        alerts.beep(frequency: frequency, duration: duration, count: count, gap: gap)
    }

    private func speak(_ text: String) {
        guard voiceMode == .voice else { return }
        alerts.say(text, lang: lang)
    }

    func testAlert() {
        beep(frequency: 1150, duration: 0.18, count: 4)
        let line = t.sayDropOver(100, 100 + tolerance)
        later(1.3) { $0.speak(line) }
    }

    // MARK: - demo

    func runDemo() {
        stopDemo()
        running = true
        demoRunning = true
        manualLimit = nil
        let steps: [(Int, Int)] = [(125, 120), (130, 120), (130, 120), (131, 100), (128, 100), (118, 100), (110, 100), (112, 100), (115, 120)]
        demoTask = Task { [weak self] in
            for (s, l) in steps {
                guard let self, !Task.isCancelled else { return }
                self.speed = s
                let old = self.autoLimit
                self.autoLimit = l; self.limitTime = Date()
                if old != l { self.limitChanged(from: old, to: l) }
                self.checkOver()
                try? await Task.sleep(nanoseconds: 2_200_000_000)
            }
            self?.demoRunning = false
            self?.stop()
        }
    }

    private func stopDemo() {
        demoTask?.cancel(); demoTask = nil; demoRunning = false
    }
}
