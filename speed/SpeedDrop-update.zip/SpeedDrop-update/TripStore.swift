import Foundation
import CoreLocation

struct TripPoint: Codable {
    let lat: Double
    let lon: Double
    let t: Date
    let kmh: Int
}

struct TripRoad: Codable, Hashable {
    let name: String
    var limit: Int?
    let t: Date
}

struct Trip: Codable, Identifiable {
    let id: UUID
    var start: Date
    var end: Date
    var points: [TripPoint] = []
    var roads: [TripRoad] = []
    var maxKmh: Int = 0
    var distance: Double = 0   // metres
    var alerts: Int = 0

    var coords: [CLLocationCoordinate2D] { points.map { CLLocationCoordinate2D(latitude: $0.lat, longitude: $0.lon) } }
}

/// Trip history, stored on this phone only (Documents/trips.json).
/// A trip starts when the car moves and ends after 5 minutes standing still,
/// when the person taps Stop, or when the app goes away.
@MainActor
final class TripStore: ObservableObject {
    @Published private(set) var trips: [Trip] = []
    @Published private(set) var current: Trip?

    private var stillSince: Date?
    private var lastSave = Date.distantPast
    private let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("trips.json")

    init() { load() }

    func record(_ loc: CLLocation, kmh: Double) {
        let now = loc.timestamp
        if kmh < 5 {
            if stillSince == nil { stillSince = now }
            if current != nil, let s = stillSince, now.timeIntervalSince(s) > 300 { finish() }
        } else {
            stillSince = nil
        }
        if current == nil {
            guard kmh >= 5 else { return }
            current = Trip(id: UUID(), start: now, end: now)
        }
        guard var tr = current else { return }
        tr.end = now
        tr.maxKmh = max(tr.maxKmh, Int(kmh.rounded()))
        if let last = tr.points.last {
            let d = loc.distance(from: CLLocation(latitude: last.lat, longitude: last.lon))
            if d < 30 && now.timeIntervalSince(last.t) < 15 {
                current = tr; saveSoon(); return
            }
            if d < 3000 { tr.distance += d }
        }
        tr.points.append(TripPoint(lat: loc.coordinate.latitude, lon: loc.coordinate.longitude,
                                   t: now, kmh: Int(kmh.rounded())))
        if tr.points.count > 4000 {
            let n = tr.points.count
            tr.points = tr.points.enumerated().filter { $0.offset % 2 == 0 || $0.offset == n - 1 }.map { $0.element }
        }
        current = tr
        saveSoon()
    }

    func road(_ name: String, limit: Int?) {
        guard var tr = current, !name.isEmpty else { return }
        if let last = tr.roads.last, last.name == name {
            if last.limit == nil, let limit { tr.roads[tr.roads.count - 1].limit = limit; current = tr }
            return
        }
        tr.roads.append(TripRoad(name: name, limit: limit, t: Date()))
        if tr.roads.count > 100 { tr.roads.removeFirst() }
        current = tr
    }

    func countAlert() { current?.alerts += 1 }

    func finish() {
        save()
        current = nil
        stillSince = nil
    }

    func delete(_ id: UUID) {
        trips.removeAll { $0.id == id }
        if current?.id == id { current = nil }
        write()
    }

    func deleteAll() {
        trips = []
        current = nil
        write()
    }

    // MARK: - persistence

    private func saveSoon() {
        if Date().timeIntervalSince(lastSave) > 10 { save() }
    }

    func save() {
        guard let tr = current, tr.points.count >= 2 else { return }
        lastSave = Date()
        if let i = trips.firstIndex(where: { $0.id == tr.id }) { trips[i] = tr } else { trips.append(tr) }
        if trips.count > 60 { trips.removeFirst(trips.count - 60) }
        write()
    }

    private func write() {
        if let data = try? JSONEncoder().encode(trips) { try? data.write(to: url, options: .atomic) }
    }

    private func load() {
        if let data = try? Data(contentsOf: url),
           let saved = try? JSONDecoder().decode([Trip].self, from: data) {
            trips = saved
        }
    }
}

// MARK: - sharing

extension Trip {
    func summary(_ t: L10n) -> String {
        var lines = [
            "\(t.tripOf) \(t.date(start))",
            "\(t.started): \(t.time(start)) — \(Self.mapsLink(points.first))",
            "\(t.ended): \(t.time(end)) — \(Self.mapsLink(points.last))",
            "\(t.duration): \(t.dur(end.timeIntervalSince(start))) · \(t.distance): \(t.km(distance))",
            "\(t.maxSpeed): \(maxKmh) · \(t.alerts): \(alerts)",
        ]
        if !roads.isEmpty {
            lines.append("\(t.roadsLabel):")
            lines += roads.map { "• \(t.time($0.t)) \($0.name)" + ($0.limit.map { " (\($0))" } ?? "") }
        }
        return lines.joined(separator: "\n")
    }

    static func mapsLink(_ p: TripPoint?) -> String {
        guard let p else { return "" }
        return String(format: "https://www.google.com/maps?q=%.5f,%.5f", p.lat, p.lon)
    }

    /// Writes the route as a GPX file to a temporary folder and returns its URL.
    func gpxFile() -> URL? {
        let iso = ISO8601DateFormatter()
        let pts = points.map { String(format: "<trkpt lat=\"%.6f\" lon=\"%.6f\"><time>%@</time></trkpt>", $0.lat, $0.lon, iso.string(from: $0.t)) }.joined()
        let gpx = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><gpx version=\"1.1\" creator=\"SpeedDrop\" xmlns=\"http://www.topografix.com/GPX/1/1\"><trk><name>Trip \(iso.string(from: start))</name><trkseg>\(pts)</trkseg></trk></gpx>"
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd-HHmm"
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("trip-\(f.string(from: start)).gpx")
        do { try gpx.write(to: url, atomically: true, encoding: .utf8); return url } catch { return nil }
    }
}
