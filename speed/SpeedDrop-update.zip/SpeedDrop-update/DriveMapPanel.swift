import SwiftUI
import MapKit

/// Live map for the drive screen: follows the car (heading-up), shows Apple's
/// live traffic, with the current speed and the speed-limit sign on top.
struct DriveMapPanel: View {
    @EnvironmentObject var model: DriveModel
    var pop: Bool
    @State private var position: MapCameraPosition = .userLocation(followsHeading: true, fallback: .automatic)

    var body: some View {
        let t = model.t
        ZStack(alignment: .topLeading) {
            Map(position: $position) {
                UserAnnotation()
            }
            .mapStyle(.standard(elevation: .realistic, pointsOfInterest: .excludingAll, showsTraffic: true))
            .mapControls {
                MapUserLocationButton()
                MapCompass()
                MapScaleView()
            }
            .clipShape(RoundedRectangle(cornerRadius: 20))

            // speed + limit sign over the map
            HStack(alignment: .center, spacing: 12) {
                VStack(spacing: 0) {
                    Text("\(model.speed)")
                        .font(.system(size: 54, weight: .heavy))
                        .fontWidth(.condensed)
                        .monospacedDigit()
                        .foregroundStyle(speedColor)
                    Text(t.yourSpeed).font(.caption2).foregroundStyle(Color.muted)
                }
                .padding(.horizontal, 14).padding(.vertical, 8)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))

                ZStack {
                    Circle().fill(Color.white)
                    Circle().strokeBorder(Color.signRed, lineWidth: 9)
                    Text(model.effectiveLimit.map(String.init) ?? "–")
                        .font(.system(size: 30, weight: .heavy))
                        .fontWidth(.condensed)
                        .monospacedDigit()
                        .foregroundStyle(Color.black)
                        .minimumScaleFactor(0.5)
                        .padding(10)
                }
                .frame(width: 74, height: 74)
                .opacity(model.limitIsStale ? 0.5 : 1)
                .scaleEffect(pop ? 1.12 : 1)
                .shadow(radius: 4)
            }
            .padding(12)
        }
    }

    private var speedColor: Color {
        switch model.status { case .over: .danger; case .inMargin: .warn; case .ok: .ok; default: .fg }
    }
}
