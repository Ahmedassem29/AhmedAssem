import Foundation
import CoreLocation

/// Road speed limits from OpenStreetMap (Overpass API).
/// Downloads the roads in a ~4 km box around the car, refreshes it as you
/// approach the edge, and matches each GPS fix to the nearest road going
/// your way.
actor SpeedLimitService {
    struct Way {
        let pts: [CLLocationCoordinate2D]
        let oneway: Bool
        let reversed: Bool
        let limit: Int?
        let forward: Int?
        let backward: Int?
        let name: String
    }

    private var ways: [Way] = []
    private var box: (s: Double, n: Double, w: Double, e: Double)?
    private var fetching = false

    private let half = 0.018       // ~2 km each side
    private let edgeMargin = 0.007 // refetch within ~750 m of the edge
    private let endpoints = [
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    ]

    var hasData: Bool { !ways.isEmpty }

    func needsFetch(_ c: CLLocationCoordinate2D) -> Bool {
        guard !fetching else { return false }
        guard let b = box else { return true }
        return c.latitude < b.s + edgeMargin || c.latitude > b.n - edgeMargin
            || c.longitude < b.w + edgeMargin || c.longitude > b.e - edgeMargin
    }

    /// Returns true on success, false on failure.
    func fetch(around c: CLLocationCoordinate2D, lang: String = "ar") async -> Bool {
        guard !fetching else { return hasData }
        fetching = true
        defer { fetching = false }
        let s = c.latitude - half, n = c.latitude + half, w = c.longitude - half, e = c.longitude + half
        let hw = "^(motorway|trunk|primary|secondary|tertiary|motorway_link|trunk_link|primary_link|secondary_link|tertiary_link|unclassified|residential)$"
        let q = "[out:json][timeout:25];way[\"highway\"~\"\(hw)\"](\(s),\(w),\(n),\(e));out tags geom;"
        let body = "data=" + (q.addingPercentEncoding(withAllowedCharacters: .alphanumerics) ?? "")

        for ep in endpoints {
            guard let url = URL(string: ep) else { continue }
            var req = URLRequest(url: url, timeoutInterval: 25)
            req.httpMethod = "POST"
            req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            req.setValue("SpeedDrop-iOS/1.0", forHTTPHeaderField: "User-Agent")
            req.httpBody = body.data(using: .utf8)
            do {
                let (data, resp) = try await URLSession.shared.data(for: req)
                guard (resp as? HTTPURLResponse)?.statusCode == 200 else { continue }
                let decoded = try JSONDecoder().decode(OverpassResponse.self, from: data)
                ways = decoded.elements.compactMap { el in
                    guard let g = el.geometry, g.count > 1 else { return nil }
                    let t = el.tags ?? [:]
                    let highway = t["highway"] ?? ""
                    return Way(
                        pts: g.map { CLLocationCoordinate2D(latitude: $0.lat, longitude: $0.lon) },
                        oneway: t["oneway"] == "yes" || highway.hasPrefix("motorway"),
                        reversed: t["oneway"] == "-1",
                        limit: Self.parseLimit(t["maxspeed"]),
                        forward: Self.parseLimit(t["maxspeed:forward"]),
                        backward: Self.parseLimit(t["maxspeed:backward"]),
                        name: t["name:\(lang)"] ?? t["name"] ?? t["ref"] ?? "")
                }
                box = (s, n, w, e)
                return true
            } catch {
                continue
            }
        }
        return false
    }

    /// Speed limit (km/h) of the road the car is on, or nil if unknown.
    func match(_ c: CLLocationCoordinate2D, heading: Double?) -> Int? {
        var bestScore = Double.greatestFiniteMagnitude
        var bestLimit: Int? = nil
        for w in ways {
            for i in 0..<(w.pts.count - 1) {
                let a = Self.xy(w.pts[i], origin: c), b = Self.xy(w.pts[i + 1], origin: c)
                let dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy
                if l2 == 0 { continue }
                let t = max(0, min(1, -(a.x * dx + a.y * dy) / l2))
                let px = a.x + t * dx, py = a.y + t * dy
                let dist = (px * px + py * py).squareRoot()
                if dist > 30 { continue }
                var score = dist
                var forward = true
                if let h = heading {
                    let d = Self.angDiff(Self.bearing(a, b), h)
                    forward = d < 90
                    let aligned = w.oneway ? (w.reversed ? d > 145 : d < 35) : (d < 35 || d > 145)
                    if !aligned { score += 80 }
                }
                if score < bestScore {
                    bestScore = score
                    bestLimit = (forward ? w.forward : w.backward) ?? w.limit
                }
            }
        }
        return bestScore <= 40 ? bestLimit : nil
    }

    /// Name of the closest road within 30 m (for the trip log).
    func nearestName(_ c: CLLocationCoordinate2D) -> String? {
        var best = 30.0, name: String? = nil
        for w in ways where !w.name.isEmpty {
            for i in 0..<(w.pts.count - 1) {
                let a = Self.xy(w.pts[i], origin: c), b = Self.xy(w.pts[i + 1], origin: c)
                let dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy
                if l2 == 0 { continue }
                let t = max(0, min(1, -(a.x * dx + a.y * dy) / l2))
                let d = ((a.x + t * dx) * (a.x + t * dx) + (a.y + t * dy) * (a.y + t * dy)).squareRoot()
                if d < best { best = d; name = w.name }
            }
        }
        return name
    }

    // MARK: - helpers

    static func parseLimit(_ v: String?) -> Int? {
        guard let v, let r = v.range(of: "[0-9]+", options: .regularExpression), var n = Int(v[r]) else { return nil }
        if v.lowercased().contains("mph") { n = Int((Double(n) * 1.609).rounded()) }
        return (10...160).contains(n) ? n : nil
    }

    static func xy(_ p: CLLocationCoordinate2D, origin o: CLLocationCoordinate2D) -> (x: Double, y: Double) {
        let r = 6_371_000.0
        let x = (p.longitude - o.longitude) * .pi / 180 * r * cos(o.latitude * .pi / 180)
        let y = (p.latitude - o.latitude) * .pi / 180 * r
        return (x, y)
    }

    static func bearing(_ a: (x: Double, y: Double), _ b: (x: Double, y: Double)) -> Double {
        let d = atan2(b.x - a.x, b.y - a.y) * 180 / .pi
        return (d + 360).truncatingRemainder(dividingBy: 360)
    }

    static func angDiff(_ a: Double, _ b: Double) -> Double {
        let d = abs(a - b).truncatingRemainder(dividingBy: 360)
        return d > 180 ? 360 - d : d
    }
}

private struct OverpassResponse: Decodable {
    struct Point: Decodable { let lat: Double; let lon: Double }
    struct Element: Decodable {
        let tags: [String: String]?
        let geometry: [Point]?
    }
    let elements: [Element]
}
