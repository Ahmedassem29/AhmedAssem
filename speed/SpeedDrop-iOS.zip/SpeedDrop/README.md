# نبّهني · SpeedDrop — iOS

## 1) حط مفتاح TomTom
افتح ملف `SpeedDrop/Config.swift` في Xcode، وحط المفتاح بين العلامتين:

```swift
static let tomTomKey = "المفتاح هنا"
```

(لو سبته فاضي، التطبيق هيشتغل على خريطة OpenStreetMap بس.)

## 2) سطّبه على موبايلك مجانًا (من غير اشتراك)

1. افتح `SpeedDrop.xcodeproj` بـ **Xcode 16** أو أحدث.
2. Xcode ← Settings ← **Accounts** ← ➕ ← Apple ID، وسجّل بالـ Apple ID العادي بتاعك.
3. من الشمال دوس على مشروع **SpeedDrop** ← Target **SpeedDrop** ← تاب **Signing & Capabilities**:
   - علّم **Automatically manage signing**.
   - في **Team** اختار اسمك (Personal Team).
   - لو طلع error إن الـ Bundle Identifier مستخدم، غيّره لأي حاجة زي `com.ahmedassem.speeddrop2`.
4. وصّل الآيفون بالكابل، واختاره من القايمة فوق جنب زرار ▶︎.
5. على الآيفون: Settings ← Privacy & Security ← **Developer Mode** ← On (هيعمل Restart).
6. دوس ▶︎ **Run**.
7. أول مرة بس: على الآيفون Settings ← General ← **VPN & Device Management** ← اسمك ← **Trust**، وبعدين افتح التطبيق.
8. لما يسألك عن الموقع اختار **Allow While Using App**.

**كل 7 أيام** التطبيق هيقف يفتح. وصّل الموبايل بالماك ودوس ▶︎ Run تاني وخلاص.

## ملاحظات
- بيشتغل والموبايل مقفول أو في جيبك (السهم الأزرق فوق هيفضل ظاهر).
- الصوت بيطلع من سماعات العربية عن طريق CarPlay، وبيوطّي صوت Waze أو الأغاني ثانية التنبيه بس.
- لو Xcode طلّع أي error، صوّره وابعته.
