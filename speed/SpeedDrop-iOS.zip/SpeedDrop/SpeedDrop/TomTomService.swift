import Foundation
import CoreLocation

/// Road speed limits from TomTom (Reverse Geocoding with returnSpeedLimit).
/// Primary source; OpenStreetMap is the fallback. Free tier ≈ 2,500 calls/day,
/// so calls are throttled (≥4 s apart, ≥120 m moved) and capped at 2,300/day.
actor TomTomService {
    private var lastCall = Date.distantPast
    private var lastCoord: CLLocationCoordinate2D?
    private var busy = false
    private(set) var limit: Int?
    private(set) var limitTime = Date.distantPast
    private(set) var roadName = ""
    private(set) var lastError = ""

    var isConfigured: Bool { !Config.tomTomKey.isEmpty }

    var freshLimit: Int? {
        guard let limit, Date().timeIntervalSince(limitTime) < 25 else { return nil }
        return limit
    }

    static var todayCount: Int {
        let d = UserDefaults.standard
        let day = Self.dayKey
        return d.string(forKey: "ttDay") == day ? d.integer(forKey: "ttCount") : 0
    }
    private static var dayKey: String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"; return f.string(from: Date())
    }
    private static func bumpCount() {
        let d = UserDefaults.standard
        let day = dayKey
        let n = (d.string(forKey: "ttDay") == day ? d.integer(forKey: "ttCount") : 0) + 1
        d.set(day, forKey: "ttDay"); d.set(n, forKey: "ttCount")
    }

    func lookup(_ c: CLLocationCoordinate2D, heading: Double?, lang: AppLang) async {
        guard isConfigured, !busy else { return }
        let now = Date()
        let moved: Double = lastCoord.map {
            CLLocation(latitude: $0.latitude, longitude: $0.longitude)
                .distance(from: CLLocation(latitude: c.latitude, longitude: c.longitude))
        } ?? .greatestFiniteMagnitude
        if now.timeIntervalSince(lastCall) < 4 { return }
        if moved < 120 && now.timeIntervalSince(lastCall) < 20 { return }
        if Self.todayCount >= 2300 { lastError = "daily limit reached"; return }

        busy = true; lastCall = now; lastCoord = c
        defer { busy = false }

        var comps = URLComponents(string: String(format: "https://api.tomtom.com/search/2/reverseGeocode/%.6f,%.6f.json", c.latitude, c.longitude))!
        var items = [
            URLQueryItem(name: "key", value: Config.tomTomKey),
            URLQueryItem(name: "returnSpeedLimit", value: "true"),
            URLQueryItem(name: "radius", value: "40"),
            URLQueryItem(name: "language", value: lang == .ar ? "ar" : "en-GB"),
        ]
        if let h = heading { items.append(URLQueryItem(name: "heading", value: String(Int(h.rounded())))) }
        comps.queryItems = items
        guard let url = comps.url else { return }

        do {
            var req = URLRequest(url: url, timeoutInterval: 8)
            if !Config.tomTomReferer.isEmpty { req.setValue(Config.tomTomReferer, forHTTPHeaderField: "Referer") }
            let (data, resp) = try await URLSession.shared.data(for: req)
            Self.bumpCount()
            guard let http = resp as? HTTPURLResponse else { return }
            guard http.statusCode == 200 else { lastError = "HTTP \(http.statusCode)"; return }
            let decoded = try JSONDecoder().decode(TTResponse.self, from: data)
            let a = decoded.addresses.first?.address
            roadName = a?.streetName ?? a?.freeformAddress ?? ""
            lastError = ""
            if let lim = SpeedLimitService.parseLimit(a?.speedLimit) {
                limit = lim; limitTime = Date()
            } else {
                limit = nil
            }
        } catch {
            lastError = (error as? URLError)?.code == .timedOut ? "timeout" : error.localizedDescription
        }
    }
}

private struct TTResponse: Decodable {
    struct Item: Decodable { let address: Address }
    struct Address: Decodable {
        let speedLimit: String?
        let streetName: String?
        let freeformAddress: String?
    }
    let addresses: [Item]
}
