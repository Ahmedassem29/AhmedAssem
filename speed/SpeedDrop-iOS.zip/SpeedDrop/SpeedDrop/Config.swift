import Foundation

/// Put your TomTom API key here (developer.tomtom.com → API & SDK Keys).
/// Leave empty to use only OpenStreetMap.
enum Config {
    static let tomTomKey = ""

    /// If the key has "Domain whitelisting" on (e.g. aahmedassem.com), requests
    /// from the app must say they come from that site. Leave as is, or set to ""
    /// if you use a separate key without domain whitelisting for the app.
    static let tomTomReferer = "https://aahmedassem.com/"
}
