import AVFoundation

/// Plays beeps and spoken alerts. Ducks Waze/music while speaking, then
/// hands audio back. Works in the background (requires the "audio"
/// background mode) and goes out through CarPlay speakers.
final class AlertPlayer: NSObject, AVSpeechSynthesizerDelegate, AVAudioPlayerDelegate {
    private let synth = AVSpeechSynthesizer()
    private var player: AVAudioPlayer?
    private var releaseWork: DispatchWorkItem?

    override init() {
        super.init()
        synth.delegate = self
        let s = AVAudioSession.sharedInstance()
        try? s.setCategory(.playback, mode: .voicePrompt,
                           options: [.duckOthers, .interruptSpokenAudioAndMixWithOthers])
    }

    // MARK: - public

    func beep(frequency: Double = 880, duration: Double = 0.16, count: Int = 3, gap: Double = 0.1) {
        activate()
        let data = Self.makeBeeps(frequency: frequency, duration: duration, count: count, gap: gap)
        player = try? AVAudioPlayer(data: data)
        player?.delegate = self
        player?.volume = 1
        player?.play()
    }

    func say(_ text: String, lang: AppLang) {
        activate()
        let u = AVSpeechUtterance(string: text)
        u.voice = AVSpeechSynthesisVoice(language: lang.speechCode)
            ?? AVSpeechSynthesisVoice(language: lang == .ar ? "ar" : "en")
        u.rate = min(AVSpeechUtteranceMaximumSpeechRate, AVSpeechUtteranceDefaultSpeechRate * 1.05)
        u.volume = 1
        if synth.isSpeaking { synth.stopSpeaking(at: .immediate) }
        synth.speak(u)
    }

    // MARK: - session

    private func activate() {
        releaseWork?.cancel()
        try? AVAudioSession.sharedInstance().setActive(true)
    }

    private func scheduleRelease() {
        releaseWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            if self.synth.isSpeaking || (self.player?.isPlaying ?? false) { return }
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        }
        releaseWork = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.6, execute: work)
    }

    func speechSynthesizer(_ s: AVSpeechSynthesizer, didFinish u: AVSpeechUtterance) { scheduleRelease() }
    func speechSynthesizer(_ s: AVSpeechSynthesizer, didCancel u: AVSpeechUtterance) { scheduleRelease() }
    func audioPlayerDidFinishPlaying(_ p: AVAudioPlayer, successfully flag: Bool) { scheduleRelease() }

    // MARK: - tone generation (16-bit mono WAV in memory)

    static func makeBeeps(frequency: Double, duration: Double, count: Int, gap: Double) -> Data {
        let rate = 22_050.0
        var samples: [Int16] = []
        let on = Int(duration * rate), off = Int(gap * rate), fade = Int(0.008 * rate)
        for _ in 0..<max(1, count) {
            for i in 0..<on {
                let phase = (Double(i) * frequency / rate).truncatingRemainder(dividingBy: 1)
                var v = phase < 0.5 ? 1.0 : -1.0             // square wave
                let edge = min(i, on - 1 - i)
                if edge < fade { v *= Double(edge) / Double(fade) }
                samples.append(Int16(v * 0.6 * Double(Int16.max)))
            }
            samples.append(contentsOf: repeatElement(0, count: off))
        }
        var d = Data()
        func u32(_ v: UInt32) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 4)) }
        func u16(_ v: UInt16) { var x = v.littleEndian; d.append(Data(bytes: &x, count: 2)) }
        let byteCount = UInt32(samples.count * 2)
        d.append("RIFF".data(using: .ascii)!); u32(36 + byteCount)
        d.append("WAVE".data(using: .ascii)!)
        d.append("fmt ".data(using: .ascii)!); u32(16); u16(1); u16(1)
        u32(UInt32(rate)); u32(UInt32(rate) * 2); u16(2); u16(16)
        d.append("data".data(using: .ascii)!); u32(byteCount)
        samples.withUnsafeBufferPointer { d.append(Data(buffer: $0)) }
        return d
    }
}
